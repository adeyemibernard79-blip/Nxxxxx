package com.nexora.play.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.nexora.play.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import kotlin.coroutines.coroutineContext

/** A legally redistributable game (open-source or freeware homebrew) listed in res/raw/free_games.json. */
data class FreeGame(
    val id: String,
    val title: String,
    val system: GameSystem,
    val description: String,
    val author: String,
    val license: String,
    val url: String,
    val fileName: String,
)

sealed interface DlState {
    /** [total] is -1 when the server doesn't say how big the file is. */
    data class Running(val done: Long, val total: Long) : DlState
    data object Done : DlState
    data class Failed(val message: String) : DlState
}

/** An error whose message is safe to show to the person using the app. */
class DownloadException(message: String) : Exception(message)

object FreeGames {

    fun load(ctx: Context): List<FreeGame> = runCatching {
        val text = ctx.resources.openRawResource(R.raw.free_games).bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val system = runCatching { GameSystem.valueOf(o.getString("system")) }.getOrNull()
                ?: return@mapNotNull null
            val fileName = File(o.getString("fileName")).name
            val ext = fileName.substringAfterLast('.', "").lowercase()
            val url = o.getString("url")
            if (ext !in system.exts || !url.startsWith("https://")) return@mapNotNull null
            FreeGame(
                id = o.getString("id"),
                title = o.getString("title"),
                system = system,
                description = o.getString("description"),
                author = o.getString("author"),
                license = o.getString("license"),
                url = url,
                fileName = fileName,
            )
        }
    }.getOrDefault(emptyList())

    /**
     * Downloads [game] into the person's ROM folder [tree].
     * The file is first fetched to the cache, checked, and only then copied into the library,
     * so a failed or cancelled download never leaves a broken game behind.
     */
    suspend fun download(
        ctx: Context,
        game: FreeGame,
        tree: Uri,
        onProgress: (done: Long, total: Long) -> Unit,
    ): Unit = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(ctx, tree)
            ?: throw DownloadException("Can't open your ROM folder. Choose it again in Library.")
        if (!root.canWrite()) {
            throw DownloadException("Nexora can't save into this folder. In Library tap \"Change folder\" and choose it again.")
        }
        if (root.findFile(game.fileName) != null) {
            throw DownloadException("${game.fileName} is already in your ROM folder.")
        }
        val tmp = File(ctx.cacheDir, "dl_${game.id}.part")
        try {
            fetch(game.url, tmp, onProgress)
            validate(tmp)
            val doc = root.createFile("application/octet-stream", game.fileName)
                ?: throw DownloadException("Couldn't create the file in your ROM folder.")
            try {
                val out = ctx.contentResolver.openOutputStream(doc.uri)
                    ?: throw DownloadException("Couldn't write to your ROM folder.")
                out.use { o -> tmp.inputStream().use { it.copyTo(o, 1 shl 16) } }
                if (doc.name != game.fileName) doc.renameTo(game.fileName)
            } catch (t: Throwable) {
                doc.delete()
                throw t
            }
        } finally {
            tmp.delete()
        }
    }

    private suspend fun fetch(url: String, dest: File, onProgress: (Long, Long) -> Unit) {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Nexora/0.2 (Android)")
        }
        try {
            val code = conn.responseCode
            if (code != HttpURLConnection.HTTP_OK) {
                throw DownloadException("The server answered with error $code. The file may have moved.")
            }
            val total = conn.contentLengthLong
            var done = 0L
            conn.inputStream.use { input ->
                dest.outputStream().use { out ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        onProgress(done, total)
                    }
                }
            }
        } catch (e: UnknownHostException) {
            throw DownloadException("Couldn't reach the server. Check your internet connection.")
        } catch (e: SocketTimeoutException) {
            throw DownloadException("The connection timed out. Try again on a better connection.")
        } catch (e: IOException) {
            throw DownloadException("The download was interrupted (${e.message ?: "network error"}).")
        } finally {
            conn.disconnect()
        }
    }

    private fun validate(f: File) {
        if (f.length() < 1024) {
            throw DownloadException("The downloaded file is too small to be a game. Try again later.")
        }
        val head = f.inputStream().use { s ->
            val b = ByteArray(64)
            val n = s.read(b)
            String(b, 0, maxOf(n, 0), Charsets.ISO_8859_1).lowercase()
        }
        if (head.contains("<!doctype") || head.contains("<html")) {
            throw DownloadException("The server sent a web page instead of the game file.")
        }
    }
}
