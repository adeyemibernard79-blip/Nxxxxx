package com.nexora.play.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexora.play.AppViewModel
import com.nexora.play.EmulatorActivity
import com.nexora.play.data.DlState

private fun fmtBytes(b: Long): String =
    if (b >= 1_048_576L) String.format("%.1f MB", b / 1_048_576.0) else "${b / 1024} KB"

@Composable
fun FreeGamesScreen(vm: AppViewModel, openLibrary: () -> Unit) {
    val ctx = LocalContext.current
    val catalog by vm.freeGames.collectAsStateWithLifecycle()
    val games by vm.games.collectAsStateWithLifecycle()
    val downloads by vm.downloads.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Free games", style = MaterialTheme.typography.headlineMedium)
                Text("Open-source and freeware homebrew that is free to share. Saved into your ROM folder.", color = Cyan)
            }
        }
        if (settings.romUri == null) {
            item {
                Column(Modifier.fillMaxWidth().glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Choose your ROM folder first. Downloaded games are saved there.")
                    Button(onClick = openLibrary) { Text("Choose ROM folder") }
                }
            }
        }
        if (catalog.isEmpty()) {
            item { Text("No free games are listed yet.") }
        }
        items(catalog, key = { it.id }) { g ->
            val installed = games.firstOrNull { it.fileName == g.fileName }
            val st = downloads[g.id]
            Column(Modifier.fillMaxWidth().glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(g.title, style = MaterialTheme.typography.titleMedium)
                Text("${g.system.label} \u2022 by ${g.author} \u2022 ${g.license} license", color = Cyan)
                Text(g.description)
                when (st) {
                    is DlState.Running -> {
                        if (st.total > 0L) {
                            LinearProgressIndicator(progress = { st.done.toFloat() / st.total.toFloat() }, modifier = Modifier.fillMaxWidth())
                            Text("${fmtBytes(st.done)} of ${fmtBytes(st.total)}")
                        } else {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            Text("${fmtBytes(st.done)} downloaded")
                        }
                    }
                    is DlState.Failed -> Text(st.message, color = MaterialTheme.colorScheme.error)
                    else -> {}
                }
                if (installed != null) {
                    Button(onClick = { EmulatorActivity.start(ctx, installed, settings.padOpacity) }) { Text("Play") }
                } else {
                    Button(onClick = { vm.download(g) }, enabled = st !is DlState.Running) {
                        Text(if (st is DlState.Failed) "Retry" else "Download")
                    }
                }
            }
        }
    }
}
